C1 linear structural input decks and reported results.
Run CalculiX with -i c1 in each mesh directory using the documented local runtime.
Regenerate/postprocess through engineering/scripts/run_c1_fea.py.
No physical specimen or force accuracy is represented by these calculations.
