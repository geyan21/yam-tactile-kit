N1 structural reproduction inputs; no physical measurements.
Run CalculiX with -i nail in each mesh directory using the documented local runtime.
mesh.inp contains all volume nodes/elements; nail.inp contains supports, pressure-patch loads and outputs.
Regenerate the visualization mesh and postprocessing through engineering/scripts/run_nail_fea.py.
The model fixes the source support faces and bonds metal interfaces. Real joints, printed frame and hardware qualification require tests.
