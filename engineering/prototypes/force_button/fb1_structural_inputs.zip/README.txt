FB1.1 linear bonded-metal structural inputs. Units N, mm, MPa.
Run the documented CalculiX 2.23 executable with -i fb1, then -i preload, in each run directory.
The full repository's run_force_button_fea.py provides generation and postprocessing.
Large raw solver outputs remain in the working build directories and can be regenerated.
No physical accuracy, fatigue or moving-robot qualification is represented.
